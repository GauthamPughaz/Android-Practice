package com.sai.gautham.weather;


        import org.xmlpull.v1.XmlPullParser;
        import org.xmlpull.v1.XmlPullParserFactory;
        import java.io.InputStream;
        import java.net.HttpURLConnection;
        import java.net.URL;


public class weatherhandle {
    private String country = "county";
    private float temperature = 0;
    private String humidity = "humidity";
    private String pressure = "pressure";

    private String weather="weather";
    private String img="img";
    private float max=0;
    private float min=0;
    private String urlString = "0";
    private XmlPullParserFactory xmlFactoryObject;
    public volatile boolean parsingComplete = true;

    public weatherhandle(String url){
        this.urlString = url;
    }

    public String getCountry(){
        return country;
    }

    public float getTemperature(){
        return temperature;
    }
    public float getMin(){
        return min;
    }
    public float getMax(){
        return max;
    }

    public String getimg(){
        return img;
    }
    public String getHumidity(){
        return humidity;
    }

    public String getPressure(){
        return pressure;
    }
    public String getWeather(){
        return weather;
    }

    public void parseXMLAndStoreIt(XmlPullParser myParser) {
        int event;
        String text=null;

        try {
            event = myParser.getEventType();

            while (event != XmlPullParser.END_DOCUMENT) {
                String name=myParser.getName();

                switch (event){
                    case XmlPullParser.START_TAG:
                        text = myParser.getText();

                        if(name.equals("city")){
                            country = myParser.getAttributeValue(null,"name");
                        }
                        else if(name.equals("humidity")){
                            humidity = myParser.getAttributeValue(null,"value");
                        }
                        else if(name.equals("pressure")){
                            pressure = myParser.getAttributeValue(null,"value");
                        }
                        else if(name.equals("temperature")){
                            temperature =Float.parseFloat(myParser.getAttributeValue(null, "value"));
                            min = Float.parseFloat(myParser.getAttributeValue(null,"min"));
                            max = Float.parseFloat(myParser.getAttributeValue(null,"max"));
                        }
                        else if(name.equals("weather")){
                            weather = myParser.getAttributeValue(null,"value");
                            img = myParser.getAttributeValue(null,"icon");
                        }
                        else{
                        }
                        break;
                    case XmlPullParser.END_TAG:
                }
                event = myParser.next();
            }
            parsingComplete = false;
        }

        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void fetchXML(){
        Thread thread = new Thread(new Runnable(){
            @Override
            public void run() {
                try {
                    URL url = new URL(urlString);
                    HttpURLConnection conn = (HttpURLConnection)url.openConnection();

                    conn.setReadTimeout(10000 );
                    conn.setConnectTimeout(15000 );
                    conn.setRequestMethod("GET");
                    conn.setDoInput(true);
                    conn.connect();

                    InputStream stream = conn.getInputStream();
                    xmlFactoryObject = XmlPullParserFactory.newInstance();
                    XmlPullParser myparser = xmlFactoryObject.newPullParser();

                    myparser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
                    myparser.setInput(stream, null);

                    parseXMLAndStoreIt(myparser);
                    stream.close();
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        thread.start();
    }
}
