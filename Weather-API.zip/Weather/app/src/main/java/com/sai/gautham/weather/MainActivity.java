package com.sai.gautham.weather;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    public String base = "http://api.openweathermap.org/data/2.5/weather?q=";
    String add="&mode=xml&APPID=edd0115a9381add269f33b0e7db26ed3";




    @Override
    protected void onCreate(Bundle savedInstanceState) {

        setContentView(R.layout.activity_main);
        super.onCreate(savedInstanceState);
        Button go=(Button)findViewById(R.id.button);
        final TextView citytext=(TextView)findViewById(R.id.textView);
        final TextView temp=(TextView)findViewById(R.id.temp);
        final TextView hum=(TextView)findViewById(R.id.humidity);
        final TextView pre=(TextView)findViewById(R.id.pressure);
        final TextView mini=(TextView)findViewById(R.id.min);
        final TextView max=(TextView)findViewById(R.id.max);
        final TextView wea=(TextView)findViewById(R.id.weather);
        final ImageView img=(ImageView)findViewById(R.id.imageView);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
       final EditText city=(EditText)findViewById(R.id.editText);

        //city.setText(url);
        go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String url = city.getText().toString();
                if (url.isEmpty()) {
                    Toast.makeText(MainActivity.this,"Enter valid input",Toast.LENGTH_LONG).show();
                } else {
                    final String finalUrl = base + url + add;

                    DecimalFormat c = new DecimalFormat("0.0");
                    weatherhandle obj = new weatherhandle(finalUrl);
                    obj.fetchXML();
                    while (obj.parsingComplete) ;
                    citytext.setText(obj.getCountry());
                    temp.setText(String.valueOf(c.format(obj.getTemperature() - 273.15)) + " \u00b0C");
                    mini.setText(String.valueOf("   Min :" + c.format(obj.getMin() - 273.15)) + "\u00b0C");
                    max.setText(String.valueOf("Max :" + c.format(obj.getMax() - 273.15)) + "\u00b0C");
                    wea.setText("\n\n" + obj.getWeather());
                    hum.setText("\n\nHumidity :\n     " + obj.getHumidity() + " " + "%");
                    pre.setText("Pressure:\n     " + obj.getPressure() + " " + "hpa");
                    String url1 = "http://openweathermap.org/img/w/" + obj.getimg() + ".png";
                    try {
                        int SDK_INT = android.os.Build.VERSION.SDK_INT;
                        if (SDK_INT > 8) {
                            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
                                    .permitAll().build();
                            StrictMode.setThreadPolicy(policy);
                            URL urlConnection = new URL(url1);
                            HttpURLConnection connection = (HttpURLConnection) urlConnection
                                    .openConnection();
                            connection.setDoInput(true);
                            connection.connect();
                            InputStream input = connection.getInputStream();
                            Bitmap myBitmap = BitmapFactory.decodeStream(input);
                            img.setImageBitmap(myBitmap);
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }


                }
            }

        });



    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
