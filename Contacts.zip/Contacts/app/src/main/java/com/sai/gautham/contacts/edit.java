package com.sai.gautham.contacts;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by gautham on 11/4/16.
 */
public class edit extends  add {
    int il=0;
    int l=0;
    ArrayList<String>name1=new ArrayList<String>();
    protected void onCreate(Bundle savedInstanceState) {
        //try {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.edit);
            Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
            setSupportActionBar(toolbar);
       // }
        final EditText update=(EditText)findViewById(R.id.editText2);
        final Button updater=(Button)findViewById(R.id. button6);

        updater.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent ik= new Intent(getIntent());
                l=ik.getIntExtra("num",0);
                //Toast.makeText(edit.this,
//
//                      String.valueOf(l)
  //                 ,Toast.LENGTH_LONG).show();
                String name = update.getText().toString();
                name1=ik.getStringArrayListExtra("namelist");


                int flag = 0;
                if (name.length() == 0) {
                    Toast.makeText(edit.this,
                    "Enter valid contact name",
                            Toast.LENGTH_LONG).show();
                } else {

                    for ( il = 0; il < l; il++) {

                        if (new String(name.toUpperCase()).equals(name1.get(il).toUpperCase())) {

                            //Toast.makeText(edit.this, "Contact Found:" + name,
                            //Toast.LENGTH_LONG).show();
                            update.setText(name1.get(il));
                            TextView txt=(TextView) findViewById(R.id.textView3);
                            txt.setText("NEW NAME");
                            updater.setText("Update");
                            //Toast.makeText(edit.this, String.valueOf(il), Toast.LENGTH_LONG).show();

                            updater.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    String name2 = update.getText().toString();


                                    //Toast.makeText(edit.this,
                                            // "Enter valid contact name",
                                      //      String.valueOf(il)+name2+name1.size()
                                        //    ,Toast.LENGTH_LONG).show();

                                        try {
                                            String uname=update(il, name2,name1.get(il),name1);
                                    //Toast.makeText(edit.this, String.valueOf(il), Toast.LENGTH_LONG).show();
                                    getIntent().putExtra("name1",uname.toString());
                                    getIntent().putExtra("loc",il);

                                    setResult(RESULT_OK, getIntent());
                                    finish();
                                        }
                                    catch(Exception e){
                                            TextView txt=(TextView) findViewById(R.id.textView3);
                                            txt.setText(String.valueOf(e));
                                        }
                                }
                            });


                            break;

                        }

                    }
                    if (flag == 0) {
                        //Toast.makeText(edit.this, "OOPs Missing",
                        //           Toast.LENGTH_LONG).show();
                    }
                }


            }
        });
    }
    @Override
    public  void onBackPressed()

    {
        //Intent i=new Intent(getApplicationContext(),MainActivity.class);
        //startActivity(i);
        finish();
    }
}
