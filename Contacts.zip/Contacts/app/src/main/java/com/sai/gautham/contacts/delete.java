package com.sai.gautham.contacts;

import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by gautham on 21/4/16.
 */
public class delete extends add {
    ArrayList<String> name1 = new ArrayList<String>();

    protected void onCreate(Bundle savedInstanceState) {
        //try {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.delete);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        Button del = (Button) findViewById(R.id.button7);
       final int pos = getIntent().getIntExtra("pos", 0);
        final int num=getIntent().getIntExtra("num",0);
        name1 = getIntent().getStringArrayListExtra("namelist");
        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(delete.this, "Deleted" + String.valueOf(pos) + String.valueOf(num), Toast.LENGTH_LONG).show();
                //Toast.makeText(delete.this, name1.get(pos), Toast.LENGTH_LONG).show();
                int nsend=delete(pos, name1);

                getIntent().putExtra("send",nsend);
                setResult(RESULT_OK, getIntent());
                finish();


            }
        });
    }


}
