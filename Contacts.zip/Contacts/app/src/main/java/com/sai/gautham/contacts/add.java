package com.sai.gautham.contacts;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.api.GoogleApiClient;

import java.util.ArrayList;

/**
 * Created by gautham on 25/3/16.
 */
public class add extends MainActivity {
     static int id = 0;
    int i = 0;
    SQLiteDatabase dbstore;
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private GoogleApiClient client;

    public add() {

    }

    public void add1(String name) {

        //Toast.makeText(add.this, "Contact added.", Toast.LENGTH_SHORT).show();
        getIntent().putExtra("name", name);
        getIntent().putExtra("neg", -1);
        setResult(RESULT_OK, getIntent());
        finish();
    }




    @Override

    protected void onCreate(Bundle savedInstanceState) {
        try {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.add);
            final EditText name = (EditText) findViewById(R.id.editText3);
            Button save = (Button) findViewById(R.id.button5);
            dbstore = this.openOrCreateDatabase("store.db", MODE_PRIVATE
                    , null);
            dbstore.execSQL("create table if not exists storetb(id integer primary key,name text)");
            int in1=getIntent().getIntExtra("val",0);
            //Toast.makeText(add.this, String.valueOf(in1), Toast.LENGTH_LONG).show();

            if(in1==0)
                --id;
           // Toast.makeText(add.this, "now"+String.valueOf(id), Toast.LENGTH_LONG).show();

            //final dbstore d = new dbstore(this);
            //name1[i]=name.getText().toString();
            save.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try {
                        String namesend = name.getText().toString();
                        insert(id, namesend);
                        //Toast.makeText(add.this, String.valueOf(id), Toast.LENGTH_LONG).show();
                        // d.insert(namesend, id);
                        id++;
                    } catch (Exception e) {
                        TextView t = (TextView) findViewById(R.id.textView2);
                        t.setText(String.valueOf(e));
                    }


                }
            });
            //Intent intent=new Intent(getApplicationContext(),MainActivity.class);

        } catch (Exception e) {
            TextView t = (TextView) findViewById(R.id.textView2);
            t.setText(String.valueOf(e));
        }
        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
    }

    public void insert(int id, String st) {
        try {

            dbstore.execSQL("delete from storetb");

            dbstore.execSQL("insert into storetb values( " + id + "," + "'" + st + "' )");
            Toast.makeText(add.this, "inserted", Toast.LENGTH_LONG).show();
            Cursor c = dbstore.rawQuery("select name from storetb where id=" + id, null);

            c.moveToFirst();
            Button save = (Button) findViewById(R.id.button5);
            String rname = "leo";

            if (c != null) {


                do {
                    rname = c.getString(c.getColumnIndex("name"));
                } while (c.moveToNext());
            }
            //save.setText(rname);


            if (rname.isEmpty() == false)
                add1(rname);
        } catch (Exception e) {
            TextView t = (TextView) findViewById(R.id.textView2);
            t.setText(String.valueOf(e));
        }
    }

    public String update(int id, String namel, String size, ArrayList<String> name1) {
        dbstore = this.openOrCreateDatabase("store.db", MODE_APPEND
                , null);

            //Toast.makeText(add.this, "updated", Toast.LENGTH_LONG).show();


                Cursor c1= dbstore.rawQuery("select id from storetb where name ='"+size+"'",null);
        c1.moveToFirst();
        int up=0;

        if (c1.getCount()>0) {


            do {
                up = c1.getInt(c1.getColumnIndex("id"));
            } while (c1.moveToNext());
        }


                dbstore.execSQL("update storetb set name ='" + namel + "' where id=" + up);
        Toast.makeText(add.this, "updated", Toast.LENGTH_LONG).show();
        Cursor c = dbstore.rawQuery("select name from storetb where id=" + up, null);

        c.moveToFirst();
        //Button save = (Button) findViewById(R.id.button5);
        String rname = "l";

        if (c.getCount()>0) {


            do {
                rname = c.getString(c.getColumnIndex("name"));
            } while (c.moveToNext());
        }
        //save.setText(rname);

        //Toast.makeText(add.this, String.valueOf(up) + rname + String.valueOf(size), Toast.LENGTH_LONG).show();
        //name1.set(id, rname);
        //Toast.makeText(add.this, name1.get(id), Toast.LENGTH_LONG).show();

        //Intent i8 = new Intent(getApplicationContext(), MainActivity.class);
        //i8.putExtra("name1",name1);
        //startActivity(i8);
        return rname;

    }
    public int delete(int id,ArrayList<String> name1) {
        dbstore = this.openOrCreateDatabase("store.db", MODE_APPEND
                , null);
        if (dbstore.isOpen())

            dbstore.execSQL("delete from storetb where id ="+id);
        Toast.makeText(add.this,"Deleted",Toast.LENGTH_LONG).show();
        return id;




    }

    @Override
    public void onStart() {
        super.onStart();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client.connect();
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "add Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app deep link URI is correct.
                Uri.parse("android-app://com.sai.gautham.contacts/http/host/path")
        );
        AppIndex.AppIndexApi.start(client, viewAction);
    }

    @Override
    public void onStop() {
        super.onStop();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "add Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app deep link URI is correct.
                Uri.parse("android-app://com.sai.gautham.contacts/http/host/path")
        );
        AppIndex.AppIndexApi.end(client, viewAction);
        client.disconnect();
    }
}
