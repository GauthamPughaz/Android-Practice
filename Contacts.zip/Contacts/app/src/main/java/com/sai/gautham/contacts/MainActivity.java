package com.sai.gautham.contacts;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
/* Respective Note Shiva and raghul:



The contents of activty-main are embedded within content_main.xml
 */

public class MainActivity extends AppCompatActivity {

    LayoutInflater inflator;
    public static ListView lV1;
    static int count;
    static int leo=0;
    static int in = 1;
    static int i1;
    public ArrayList<String> name1 = new ArrayList<String>();//={"Gautham","leo","jack","rio","john","henry","kennedy","micheal","johnson","David"};
    int img = R.drawable.contact;//,R.drawable.contact,R.drawable.contact,R.drawable.contact,R.drawable.contact,R.drawable.contact,R.drawable.contact,R.drawable.contact,R.drawable.contact};


    @Override
    protected void onCreate(Bundle savedInstanceState) {

            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
            setSupportActionBar(toolbar);

            //del.setVisibility(View.INVISIBLE);


            lV1 = (ListView) findViewById(R.id.listView);

            //lV1.setAdapter(new dataListAdapter(name1, img));
            final EditText contact = (EditText) findViewById(R.id.editText);
            Button search = (Button) findViewById(R.id.button);
            final Button az = (Button) findViewById(R.id.button2);
            final Button za = (Button) findViewById(R.id.button3);
            final Button adder = (Button) findViewById(R.id.button4);


            // if (name1.size()!=0) {
            ;
            //lV1.setAdapter(new dataListAdapter(name1.toArray(new String[name1.size()]), img));
            search.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    String name = contact.getText().toString();


                    int flag = 0;
                    if (name.length() == 0) {
                        Toast.makeText(MainActivity.this, "Enter valid contact name",
                                Toast.LENGTH_LONG).show();
                    } else {
                        for (int i = 0; i < name1.size(); i++) {

                            if (new String(name.toUpperCase()).equals(name1.get(i).toUpperCase())) {

                                Toast.makeText(MainActivity.this, "Contact Found:" + name,
                                        Toast.LENGTH_LONG).show();
                                flag = 1;
                                break;

                            }

                        }
                        if (flag == 0) {
                            Toast.makeText(MainActivity.this, "OOPs Missing",
                                    Toast.LENGTH_LONG).show();
                        }
                    }


                }
            });
            az.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    int i = 0, j = 0;
                    for (i = 0; i < name1.size() - 1; i++) {
                        for (j = i + 1; j < name1.size(); j++) {
                            if (name1.get(i).compareTo(name1.get(j)) > 0) {
                                //String temp = name1.get(i);
                                //name1.add(i) = name1.get(j);
                                //name1[j] = temp;
                                Collections.swap(name1, i, j);
                                /*int temp1 = img[i];
                                img[i] = img[j];
                                img[j] = temp1;*/
                            }
                        }
                    }
                    ListView lV1 = (ListView) findViewById(R.id.listView);

                    lV1.setAdapter(new dataListAdapter(name1.toArray(new String[name1.size()]), img));
                }
            });
            za.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    int i = 0, j = 0;
                    for (i = 0; i < name1.size() - 1; i++) {
                        for (j = i + 1; j < name1.size(); j++) {
                            if (name1.get(i).compareTo(name1.get(j)) < 0) {
                                //String temp = name1[i];
                                //name1[i] = name1[j];
                                //name1[j] = temp;
                                Collections.swap(name1, i, j);
                                /*int temp1 = img[i];
                                img[i] = img[j];
                                img[j] = temp1;*/
                            }
                        }
                    }
                    ListView lV1 = (ListView) findViewById(R.id.listView);

                    lV1.setAdapter(new dataListAdapter(name1.toArray(new String[name1.size()]), img));
                }
            });

            adder.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(getApplicationContext(), add.class);

                    i.putExtra("val",in);
                    startActivityForResult(i, 1);


                }

            });

        }




    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(data!=null)
        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {



                int negl = data.getIntExtra("neg", 0);

                if (negl < 0) {
                    String result = data.getStringExtra("name");

                    img = R.drawable.contact;
                    if(in==0&&count==1)
                        --i1;
                    else if(in==0&&count==2)
                        i1=i1-2;
                    count=0;
                    name1.add(i1, result);
              //      Toast.makeText(MainActivity.this, String.valueOf(i1), Toast.LENGTH_LONG).show();

                    i1++;

                    ListView lV1 = (ListView) findViewById(R.id.listView);

                    lV1.setAdapter(new dataListAdapter(name1.toArray(new String[name1.size()]), img));

                    // d.notifyDataSetChanged();


                    startActivity(getIntent());
                    //ArrayAdapter<String> adapter=new ArrayAdapter(this,R.layout.listcomps,name1);

                }
                //adapter.notifyDataSetChanged();

            }
        }
        else if(requestCode==0) {
            //Intent kl=new Intent(getIntent());
            String namek=data.getStringExtra("name1");
            int loc=data.getIntExtra("loc",0);
            name1.set(loc,namek);
            //Toast.makeText(MainActivity.this, namek+String.valueOf(loc), Toast.LENGTH_LONG).show();
            ListView lV1 = (ListView) findViewById(R.id.listView);

            lV1.setAdapter(new dataListAdapter(name1.toArray(new String[name1.size()]), img));

            // d.notifyDataSetChanged();


            startActivity(getIntent());


        }
        else
        {int rec=data.getIntExtra("send",0);

            name1.remove(rec);
            in=0;
            leo=0;
            ++count;
            ListView lV1 = (ListView) findViewById(R.id.listView);

            lV1.setAdapter(new dataListAdapter(name1.toArray(new String[name1.size()]), img));
            startActivity(getIntent());

        }



    }

    class dataListAdapter extends BaseAdapter {
        String[] name1;
        int imge;

        dataListAdapter() {

            name1 = null;
            imge = 0;
        }

        public dataListAdapter(String[] text1, int text3) {

            name1 = text1;
            imge = text3;

        }

        public int getCount() {
            // TODO Auto-generated method stub
            return name1.length;
        }

        public Object getItem(int arg0) {
            // TODO Auto-generated method stub
            return null;
        }

        public long getItemId(int position) {
            // TODO Auto-generated method stub
            return position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {

            LayoutInflater inflater = getLayoutInflater();
            View row;
            row = inflater.inflate(R.layout.listcomps, parent, false);
            TextView name;
            ImageView i1;
            ImageButton del;
            name = (TextView) row.findViewById(R.id.textView);
            i1 = (ImageView) row.findViewById(R.id.imageView2);
            del = (ImageButton) row.findViewById(R.id.imageButton);
            if(leo==1) {
                del.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        ListView lV1 = (ListView) findViewById(R.id.listView);
                        final int pos = lV1.getPositionForView((View) v.getParent());
                        Intent i3 = new Intent(MainActivity.this, delete.class);
                        //name1.remove(pos);
                        //i3.putExtra("num", name1.size());
                        i3.putExtra("namelist", name1);
                        i3.putExtra("pos", pos);
                        startActivityForResult(i3, 2);
                    }
                });
            }
            name.setText(name1[position]);
            i1.setImageResource(imge);


            return (row);
        }
    }





    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);


        return true;}

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        switch(item.getItemId())
        {
            case R.id.edit:
                Intent  i2= new Intent(MainActivity.this,edit.class);

               //Toast.makeText(MainActivity.this,String.valueOf(name1.size()),
                //        Toast.LENGTH_LONG).show();
                i2.putExtra("num", name1.size());
                i2.putExtra("namelist", name1);
                startActivityForResult(i2, 0);
                break;
            case R.id.delete:
                ImageButton del=(ImageButton) findViewById(R.id.imageButton);
                leo=1;

                ListView lV1 = (ListView) findViewById(R.id.listView);

                lV1.setAdapter(new dataListAdapter(name1.toArray(new String[name1.size()]), img));

                //del.setVisibility(View.VISIBLE);




                break;

        }
        return super.onOptionsItemSelected(item);
    }

}
